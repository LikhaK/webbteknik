<?php
// Checks whether upload button has been pressed
if (isset($_POST['upload'])) {
// Sets max filesize (1 MB = 1048576 bytes)
$max_file_size = 1048576;
// Sets accepted image files
$file_types = array('gif', 'jpg', 'jpeg', 'png');
// Sets folder for upload
$upload_dir = 'photos/';
// Creates array for storing error messages
$errors = array();
// Sets information of uploaded file
$file_tmp = $_FILES['photo']['tmp_name'];
$file_name = $_FILES['photo']['name'];
$file_size = $_FILES['photo']['size'];
$file_uniq = uniqid();
$file_ext = pathinfo($file_name, PATHINFO_EXTENSION);
// Sets path to save uploaded file
$file_save = $upload_dir . $file_uniq . '-original.' . $file_ext;
// Checks if file is a photo
if (!getimagesize($file_tmp)) {
$errors[] = 'Picture is not a photo';
}
// Checks photo filesize
if ($file_size > $max_file_size) {
$errors[] = 'Choosen file are to large';
}
// Checks if uploaded file is an accepted type
if (!in_array($file_ext, $file_types)) {
$errors[] = 'Not guilty filetype';
}
// Checks if errors has been set
if (count($errors) == 0) {
// Saves uploaded file to folder
if (move_uploaded_file($file_tmp, $file_save)) {
// Creates session for original name and thumb
$_SESSION['file_original'] = $file_uniq . '-original.' . $file_ext;
$_SESSION['file_thumb'] = $file_uniq . '-thumb.' . $file_ext;
// Redirects user to resize page
header('Location: ../../resize.php');
exit();
} else {
$errors[] = 'Woops something does not add up';
}
}
}
?>
<?php
    $mysqli = new mysqli("localhost", "root", "", "codeanywhere");
    $sql = "SELECT * FROM user WHERE subject = ?";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param('s', $_GET['subject']);
    $stmt->execute();
    $results = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>
<?php
//Gets all information from database 
    $sql = 'SELECT * FROM user WHERE uid = :uid';
    //prepares a query 
    $stmt = $dbh->prepare($sql);
    $stmt->bindValue('uid', $SESSION['uid']);
    //sends query to database 
    $stmt->execute();
?>

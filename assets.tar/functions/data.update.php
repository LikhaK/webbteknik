<?php
  // Checks whether the update button has been pressed 
  if (isset($_POST['modify'])){
      //create a query
      $sql = '
      UPDATE user
      SET firstname = :firstname,
          lastname    = :lastname,
          age    = :age,
          email    = :email,
      WHERE uid  = :uid
      ';
  //Prepare a query
  $stmt = $dbh->prepare($sql);
  //Connects form fields with db
  $stmt->bindValue(':firstname', $_POST['firstname']);
  $stmt->bindValue(':lastname', $_POST['lastname']);
  $stmt->bindValue(':age', $_POST['age']);
  $stmt->bindValue(':email', $_POST['email']);
  $stmt->bindValue(':uid', $_POST['userid']);
// Sends query to database
if ($stmt->execute()){
    header('Location: ../../profile.php');
    exit();
 }
}
?>
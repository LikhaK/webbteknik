<?php
// Checks whether delete button is pressed
if (isset($_POST['delete'])) {
// Creates a query
$sql = '
DELETE FROM user
WHERE uid = :uid
';
    // Prepares a query
    $stmt = $dbh->prepare($sql);
    // Connects form fields with containers
    $stmt->bindValue(':uid', $_POST['userid']);
    // Sends query to database
    if ($stmt->execute()) {
    header('Location: ../../index.php');
    exit();
 }
}
?>
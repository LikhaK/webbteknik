<?php
  //Checks whether user has pressed registration button 
  if (isset($_POST['register'])){
     //Gets information from form fields
     $firstname = strtolower($_POST['firstname']);
     $lastname  = strtolower($_POST['lastname']);
     $age       = ($_POST['age']);
     $email     = strtolower($_POST['email']);
     $password  = ($_POST['password']);
     
   //Creats query to database
   $sql = '
        INSERT INTO user (firstname, lastname, age, email, password, regdate)
        VALUES (:firstname, :lastname, :age, :email, :password, NOW())
   ';
   //Prepare the query
   $stmt = $dbh->prepare($sql);
   //Conects emty placeholders with form fields
   $stmt->bindValue(':firstname', $firstname);
   $stmt->bindValue(':lastname', $lastname);
   $stmt->bindValue(':age', $age);
   $stmt->bindValue(':email', $email);  
   $stmt->bindValue(':password', $password);  
   
   if ($stmt->execute()) {
   header('Location:../../profile.php');
   exit();
   }
}
?>
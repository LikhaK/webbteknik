<?php
?>
<!DOCTYPE html>
<html lang="sv">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!--Bootstrap Css-->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!--Font-Awesome Css-->
    <link rel="stylesheet" href="assets/css/all.min.css">
    <!-- JCrop CSS -->
    <link rel="stylesheet" href="assets/css/jcrop.min.css">
    <!--Custome Css-->
    <link rel="stylesheet" href="assets/css/our.css?<?php echo hash_file('md5', 'assets/css/our.css'); ?>">
</head>
<!-- Includes javascript for dropdown menu -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

<body>
    <!-- Navbar -->
    <header class="p-3 mb-3 border-botttom">
        <nav class="navbar navbar-expand-lg bg-light">
            <div class="container d-flex justify-content-between">
                <a href="index.php" class="navbar-brand">
                    A R<i class="fa-solid fa-earth-americas"></i>und
                </a>
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a href="index.php" class="nav-link">Start</a></li>
                    <li class="nav-item"><a href="map.php" class="nav-link">Countries</a></li>
                    
                    <?php
                        if (!isset($_SESSION['uid']) || empty($_SESSION['uid'])) {
                            echo '
                                <li class="nav-item">
                                    <div class="dropdown"> 
                                        <a href="profile.php" class="dropdown-toggle nav-link" data-bs-toggle="dropdown"> 
                                            <i class="fa-solid fa-circle-user"></i> Login 
                                        </a> 
                                        <div class="dropdown-menu dropdown-menu-end">
                                            <form action="index.php" method="post" class="px-4 py-3">
                                                <div class="mb-3">
                                                    <label for="email" class="form-label">Email</label>
                                                    <input type="email" class="form-control" id="email" name="email">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="password" class="form-label">Password</label>
                                                    <input type="password" class="form-control" id=" password " name="password">
                                                </div>
                                                <button type="submit" class="btn" name="login">Login</button>
                                            </form>
                                            <div class="dropdown-divider"></div>
                                                <a class="dropdown-item" href="add.php">New? Sign up now!</a>
                                                <a class="dropdown-item" href="#">Forgot your password?</a>
                                            </div>
                                        </div> 
                                    </li>
                                ';
                                } else {
                                    echo '
                                        <li class="nav-item">
                                            <a href="profile.php" class="nav-link">
                                                <i class="fas fa-user-circle"></i> Profile
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="logout.php" class="nav-link">
                                                <i class="fas fa-sign-out-alt"></i> Logout
                                            </a>
                                     </li>
                                '; 
                                }
                            ?>
                        </ul>
                    </div>
                 </nav>
             </header>
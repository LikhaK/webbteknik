<!-- JQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<!--Bootstrap JS -->
<script
src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- JCrop JS -->
<script src="assets/js/jcrop.min.js"></script>
<script src="assets/js/resize.js"></script>
<!--contact information-->
<html>
<body>
<div class="container d-flex justify-content-between">
<footer class="footer d-none d-md-block">
    <div class="footer1"><h3>Around</h3>
        <p>Find your travelbuddies</p>
        <p>Keep a good vibe</p>
        <p>Adress:<br>blahablaha <br>123 45 blahablaha</p>
        <a href="tel:012-"><i class="fa-solid fa-phone"></i> 012-3456789</a>
        <a href="mailto:info@around.se"><i class="fa-solid fa-envelope"></i> info@around.se</a>
    </div> 
    <div class="footer2"><h3>Sociala medier</h3>
        <a href=""><i class="fa-brands fa-facebook"></i> A-round</a>
        <a href=""><i class="fa-brands fa-instagram"></i> Around</a>
        <p>Copyright info</p>
    </div>
<!--Social links-->
<i class="fa-solid fa-share"></i>
<p> Dela via</p>
<section class="social-links">
   <a href="#"><i class="fa-brands fa-facebook"></i></a>
   <a href="#"><i class="fa-brands fa-instagram"></i></a>
   <a href="#"><i class="fa-brands fa-twitter"></i></a>
   <a href="#"><i class="fa-brands fa-flickr"></i></a>
   <a href="#"><i class="fa-brands fa-tumblr"></i></a>
</div>
</section>
</footer>
</body>
</html>
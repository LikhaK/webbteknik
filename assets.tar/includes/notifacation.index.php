<?php
// Checks if an action is set
if (isset($_GET['login'])) {
// Checks which action is set
switch ($_GET['login']) {
case 'empty':
echo '
<div class="alert alert-warning">
You have not enterd a username or password!
</div>
';
break;
case 'error':
echo '
<div class="alert alert-danger">
Your username or password are incorrect!
</div>
';
break;
case 'logout':
    echo '
    <div class="alert alert-success">
    You have loged out! :-)
    </div>
    ';
    break;
    case 'noauth':
        echo '
        <div class="alert alert-primary">
        You have to login to continue!
        </div>
        ';
        break;
}
}
?>